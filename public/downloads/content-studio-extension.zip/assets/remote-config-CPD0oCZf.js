async function e(){await chrome.storage.local.remove(["remoteBanners","remoteBanners_lastFetch"])}const a=e;async function t(){return null}async function s(n){}export{a,s as d,e as f,t as g};
//# sourceMappingURL=remote-config-CPD0oCZf.js.map
