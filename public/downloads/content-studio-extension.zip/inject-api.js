(() => {
  const callbacks = /* @__PURE__ */ new Map();
  let onTaskUpdate = null;
  let onConsoleLog = null;
  function call(message, callback) {
    const eventID = Math.floor(Date.now() + Math.random() * 100);
    callbacks.set(eventID, callback);
    window.postMessage(JSON.stringify({ ...message, eventID }), "*");
  }
  const poster = {
    versionNumber: 1001,
    dev: location.hostname === "localhost" || location.hostname === "127.0.0.1",
    getAccounts(callback) {
      call({ method: "getAccounts" }, callback);
    },
    addTask(task, statusHandler, callback) {
      onTaskUpdate = statusHandler;
      call({ method: "addTask", task }, callback);
    },
    magicCall(data, callback) {
      call({ method: "magicCall", methodName: data.methodName, data }, callback);
    },
    updateDriver(data, callback) {
      call({ method: "updateDriver", data }, callback);
    },
    startInspect(handler, callback) {
      onConsoleLog = handler;
      call({ method: "startInspect" }, callback);
    },
    uploadImage(data, callback) {
      call({ method: "magicCall", methodName: "uploadImage", data }, callback);
    }
  };
  window.addEventListener("message", (event) => {
    try {
      const action = JSON.parse(event.data);
      if (!action || typeof action !== "object") return;
      const message = action;
      if (message.method === "taskUpdate") {
        onTaskUpdate?.(message.task);
        return;
      }
      if (message.method === "consoleLog") {
        onConsoleLog?.(message.args);
        return;
      }
      if (!message.callReturn || typeof message.eventID !== "number") return;
      callbacks.get(message.eventID)?.(message.result);
      callbacks.delete(message.eventID);
    } catch {
    }
  });
  window.$poster = poster;
  window.$syncer = poster;
})();
